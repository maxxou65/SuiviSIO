<header>
	<a href="../accueil.php"><span class="img"></span></a>
	<span class="titre_entete">Suivi des SIO - Module stages &amp; entreprises</span>
</header>