<footer>
	<p>Section de Technicien Supérieur SIO (STS SIO) - Lycée Merleau-Ponty</p>
	<!--
	Ca, ca marche pas ... pour l'instant
	http://fr.openclassrooms.com/informatique/cours/affichez-le-nombre-de-visiteurs-connectes
	-->
	<?php include_once( 'connexion/connexion_by_id.php' );?>
	<?php include_once( 'struct/connectes.php'); ?>
</footer>