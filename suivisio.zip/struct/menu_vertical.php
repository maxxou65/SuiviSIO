<nav class="menu_vertical">
	<ul>
		<!-- Retour vers l'accueil -->
		<li id="home" class="menu_header"><a href="../accueil.php"><img src="../img/home_16-16.png">Accueil</a></li>
		<!-- Etudiants -->
		<li class="separateur"></li>
		<li class="menu_header">Etudiants</li>
		<li class="separateur"></li>
		<li class="menu_elt"><a href="../mod_etudiants/ajout_etudiants.php"><img src="../img/arrleft_16-16.png">Ajouter</a></li>
		<li class="menu_elt"><a href="#"><img src="../img/arrleft_16-16.png">Modifier</a></li>
		<li class="menu_elt"><a href="../mod_etudiants/valider_etudiants.php"><img src="../img/arrleft_16-16.png">Valider</a></li>
		<li class="menu_elt"><a href="../mod_etudiants/expl_donnes_etudiants.php"><img src="../img/arrleft_16-16.png">Consulter</a></li>
		<!-- Stages -->
		<li class="separateur"></li>
		<li class="menu_header">Stages</li>
		<li class="separateur"></li>
		<li class="menu_elt"><a href="../mod_stages/aj_donnes_stages.php"><img src="../img/arrleft_16-16.png">Ajouter</a></li>
		<li class="menu_elt"><a href="../mod_stages/modif_donnes_stages.php"><img src="../img/arrleft_16-16.png">Modifier</a></li>
		<li class="menu_elt"><a href="../mod_stages/sup_donnes_stages.php"><img src="../img/arrleft_16-16.png">Supprimer</a></li>
		<li class="menu_elt"><a href="../mod_stages/expl_donnes_stages.php"><img src="../img/arrleft_16-16.png">Consulter</a></li>
		<!-- Diplomés -->
		<li class="separateur"></li>
		<li class="menu_header">Diplomés</li>
		<li class="separateur"></li>
		<li class="menu_elt"><a href="#"><img src="../img/arrleft_16-16.png">Gérer</a></li>
		<li class="menu_elt"><a href="#"><img src="../img/arrleft_16-16.png">Consulter</a></li>
		<li class="menu_elt"><a href="#"><img src="../img/arrleft_16-16.png">Modifier</a></li>
		<li class="menu_elt"><a href="#"><img src="../img/arrleft_16-16.png">Consulter</a></li>
	</ul>
</nav>