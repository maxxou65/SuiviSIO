<?php
if (!empty($message)) {
	echo '<div class="message">';
	echo '<div>'."Message d'information".'</div>'.'<ul>';
	echo $message;
	echo '<ul>'.'</div>';
}
?>