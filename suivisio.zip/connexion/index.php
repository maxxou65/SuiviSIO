<?php
//redirige vers le dossier parent
	header("Location : ../");
?>