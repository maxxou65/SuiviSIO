<?php
if(isset($_POST['ID_CONNEXION'])) {

	include_once("./connexion/connexion_by_id.php");
	$connexion = getConnexion("agent_conn", "");

	$req = "SELECT `ID_CONNEXION`, `MDP_CONNEXION` FROM `CONNEXION`;";
	$res = $connexion->query($req);
	$table_connexion = $res->fetchAll( PDO::FETCH_ASSOC);

	foreach ($table_connexion as $table) {
			if ($table == $_POST) {
				session_start();
				$_SESSION['CONNEXION']['ID_CONNEXION'] = trim(strtolower($_POST['ID_CONNEXION']));;
				$_SESSION['CONNEXION']['MDP_CONNEXION'] = trim(strtolower($_POST['MDP_CONNEXION']));

				header('Location: ./accueil.php');
				exit;
			} else {
				$message = "Identifiant ou mot de passe incorrect.";
			}
		}
}
?>
<!DOCTYPE html>
<html>
<head>
	<?php include("./struct/param_head.php"); ?>
	<link rel="stylesheet" type="text/css" href="./css/connexion.css">
	<title>Suivi des SIO</title>
</head>
<body><!--
	entête (header)
--><?php include("./struct/entete.php"); ?><!--
--><span></span><!--
	contenu de la page
--><section id="conn_app" class="document">
	<div class="placer">
		<span>Bienvenue sur l'application de suivi des SIO</span>
		<span>Veuillez vous identifier</span>
		<span>DEV : identifiants sur <a href="https://docs.google.com/document/d/1a-EozVGOWWxz1mXsIj-AUmk2N6XvXen7rObEyL8bI08/edit">Google drive</a></span>
		<form action="index.php" method="post"><!--
		 --><div>
			 	<label for="ID_CONNEXION">Identifiant</label>
			 	<input id="ID_CONNEXION" class="transition" type="text" name="ID_CONNEXION" tabindex="1">
			</div><!--
		 --><div>
			 	<label for="MDP_CONNEXION">Mot de passe</label>
			  	<input id="MDP_CONNEXION" type="password" name="MDP_CONNEXION" tabindex="2"><!--
		 --></div>
		 <input class="submit transition" class="transition" type="submit" value="Connexion" tabindex="3">
		</form>	
		
		<?php
			if (isset($message)) {
				echo '<span class="message">';
				echo $message;
				echo '</span>';
			}
		?>
		
	</div>
</section><!--
	Pied de page (footer)
--><?php include("./struct/pieddepage.php"); ?>
</body>
</html>
