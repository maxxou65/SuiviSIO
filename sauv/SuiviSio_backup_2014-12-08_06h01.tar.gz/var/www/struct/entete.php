<header>
	<a href="../accueil.php"><span class="img"></span></a>
	<span class="titre_entete">Suivi des SIO</span>
</header>