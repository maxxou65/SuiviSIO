<nav class="menu_horizontal">
	<ul>
		<li><a href="../mod_etudiants/index_etudiants.php">MODULE ETUDIANTS</a></li><!--
		--><li><a href="../mod_stages/index_stages.php">MODULE STAGES &amp; ENTREPRISES</a></li><!--
		--><li><a href="../mod_devenirs/index_devenirs.php">MODULE DEVENIRS &amp; DIPLOMES</a></li>
	</ul>
</nav>