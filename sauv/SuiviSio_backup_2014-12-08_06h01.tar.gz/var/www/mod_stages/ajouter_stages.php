<?php
// <!--
// ================================
// 	Création de la session
// 	Redirection des utilisateurs non identifié
// ================================
// -->

include("../struct/session.php");
$_SESSION['MOD']="_"."stages";
$mod=$_SESSION['MOD'];

// <!--
// ================================
// 	Inclusion des fichiers permettant l'affichage des listes déroulantes
// 	Initialisation des variables
// ================================
// -->


// Inclusion de tous les fichiers comportant une ou des fonctions de listes déroulantes
// On met tout les suffixes des fichiers dans un tableau
$tables=array("prof","date","classe","etudiant","tuteur","entreprise");
// On compte le nombre de suffixes présents dans le tableau, et on inclue les fichiers comportant le suffixe demandé.
for($i=0;$i<count($tables);$i++)
{
	include_once("../fonctions/liste_deroulante_".$tables[$i].".php");
}
include_once("../fonctions/radio_bouton_classe.php");

/* VARIABLES */
$id_tuteur=0;
$id_etu=0;
$id_periode="";
$id_entr=0;
$id_prof_superviseur=0;
$id_prof_visiteur=0;
$code_classe="SIO1";

?>
<!DOCTYPE html>
<html>
<head>
	<!--
	================================
		paramètres du <head>
		commun aux pages (inclusion de fichiers CSS, JS; balise meta; ...) 
	================================
	-->
	<?php include("../struct/param_head.php");
	echo '<title>'."Ajout d'un stage".$title.'</title>';
	// nom de votre page
	?>
	<link rel="stylesheet" type="text/css" href="../css/stage.css">
</head>
<?php

// Récupération des données du formulaire
$confirmation="";
if(	isset($_POST['ID_TUTEUR'])&&isset($_POST['ID_ETUDIANT'])&&
	isset($_POST['ID_ENTREPRISE'])&&isset($_POST['ID_DPERIODE'])&&
	isset($_POST['ID_PROF_SUPERVISEUR'])&&isset($_POST['CODE_CLASSE'])){
	//echo "<h1>Formulaire validé</h1>";	
	$id_tuteur=$_POST['ID_TUTEUR'];
	$id_etu=$_POST['ID_ETUDIANT'];
	$id_periode=$_POST['ID_DPERIODE'];
	$id_entr=$_POST['ID_ENTREPRISE'];
	//*
		if($_POST['ID_PROF_VISITEUR']!=''){	
		$id_prof_superviseur=$_POST['ID_PROF_VISITEUR'];
	}//*/
	$id_prof_visiteur=$_POST['ID_PROF_VISITEUR'];
	$code_classe=$_POST['CODE_CLASSE'];
	
/* Mettre à jour sur la base de données*/
	//faire la requete pour inserer avec le try et le catch
	//*
	try{
		$requete="insert into STAGE(ID_TUTEUR,ID_PROF,ID_ETU,ID_ENTREPRISE,ID_PERIODE,ID_PROF_VISITER,CLASSE_STAGE)
		values($id_tuteur,$id_prof_superviseur,$id_etu,$id_entr,$id_periode,$id_prof_visiteur,'$code_classe');";
		$connexion->exec($requete);
		$message="";
	}
	catch(PDOException $e)
	{
		$message="probleme pour insérer les informations sur un stage effectué ";
		$message=$message.$e->getMessage();
		//echo $message;
	}
	if($message==""){
		$confirmation="Stage ajoutée";
	}//*/
	else{
		$confirmation="Un champ est manquant ou non valide";
	}
}
?>
<body><!-- entête (header) 
--><?php include("../struct/entete".$mod.".php"); ?><!-- menu horizontal 
--><?php include("../struct/menu_horizontal.php"); ?><!-- menu vertical 
--><?php include("../struct/menu_vertical".$mod.".php"); ?><!--
	contenu de la page
	appliquez un ID sur votre section pour y appliquer un style particulier en CSS
--><section id="ajouter" class="document">
																		<!-- Endroit où il faut modifier -->

		<!-- 
			Formulaire d'ajout de stage aux étudiants 
		-->
		<?php include("../mod_stages/formulaires/formulaire_ajout_stage.php"); ?>
		<!--
			Message donnant l'état de validation du formulaire.
			Stage ajouté ou Message disant qu'il y a une erreur au moins
		-->
		<br/><br/><p id='confirmation'><b><?php echo $confirmation ?></b></p>
		<!--
			Formulaire d'ajout d'entreprise
		-->
		<?php //include("../formulaires/formulaire_ajout_entreprise.php"); ?>
		<!--
			<p>Olivier, jete un coup d'oeil aux <a href="http://www.w3schools.com/tags/tag_datalist.asp">éléments datalist</a>, 
			ça pourrait peut être t'aider ;)
			<br>Anthony.
		</p>-->
		<!--
			Pour les radios boutons:
			http://openclassrooms.com/forum/sujet/recuperer-les-valeurs-des-boutons-type-radio-avec-ajax-94520
			http://openclassrooms.com/courses/dynamisez-vos-sites-web-avec-javascript/xmlhttprequest-1
		-->
	</div>
</section>
<script src="../js/jquery.js"></script>
<!-- 
	Modification de la liste déroulante d'étudiant en fonction de la classe choisie (sio1 ou sio2) 
-->
<script src="../js/modifier_liste_etudiant_stage.js" type="text/javascript"></script>
<script src="../js/valider_recherche_entreprise_stage.js" type="text/javascript"></script>
<!--
	Pied de page (footer)
--><?php include("../struct/pieddepage.php"); ?>
</body>
</html>