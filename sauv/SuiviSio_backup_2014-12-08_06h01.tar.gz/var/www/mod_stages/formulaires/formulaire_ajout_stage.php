﻿	<form action="ajouter_stages.php" method="post"><!--
	 --><div>
			<h2>Formulaire d'ajout d'un stage</h2>
		</div><!--
	 --><div class="radio">
			<label for="CODE_CLASSE">Classe</label>
			<!--<input name="NOM" value="<?php //echo $nom; ?>" type="text" id="nom">-->
			<?php echo donner_radio_bouton_classe($connexion,$code_classe); ?>
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="ID_ETUDIANT">Etudiant</label>
			<!--<input name="NOM" value="<?php //echo $nom; ?>" type="text" id="nom">-->
			<?php echo lister_etudiant2($connexion,$id_etu,$code_classe); ?>
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="ID_ENTREPRISE">Entreprise</label>
			<?php echo rechercher_entreprise($connexion,$id_entr); ?>
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="ID_TUTEUR">Tuteur</label>
			<!--<input name="ADRESSE" value="<?php //echo $adresse; ?>" type="text" id="adresse">-->
			<?php echo lister_tuteur($connexion,$id_tuteur); ?>
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="CODE_STAGE">Date de stage</label>
			<?php echo lister_date($connexion,$id_periode); ?>
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="ID_PROF_SUPERVISER">Superviseur</label>
			<?php echo lister_superviseur($connexion,$id_prof_superviseur); ?>
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="ID_PROF">Visiteur</label>
			<?php echo lister_visiteur($connexion,$id_prof_visiteur); ?>
			<span class="hint"></span>
		</div><!--
	 --><div>
	 		<input class="submit transition" type="submit" value="Soumettre">
	 	</div>
	</form>