<?php
// ================================
// 	Création de la session
// 	Redirection des utilisateurs non identifié
// ================================


include_once('../struct/session.php');
$_SESSION['MOD'] = "_"."stages"; // définition du module
$mod = $_SESSION['MOD'];

// ================================
// 	Si formulaire soumis
// ================================

if (isset($_POST)) {

	$estVide = FALSE;
	foreach($_POST as $row) { 
		if (trim($row) == "")
			$estVide = TRUE;
	}

	if ($estVide == TRUE) { // Si formulaire vide
		
		$message = newLineMsg("Remplissez au moins le formulaire ...");

	} elseif ($estVide == FALSE) {

		$nom = $_POST['NOM'];
		$type = $_POST['TYPE'];
		$adresse = $_POST['ADRESSE'];
		$cpost = $_POST['CPOST'];
		$ville = $_POST['VILLE'];
		$tel = $_POST['TEL'];
		$mail = $_POST['MAIL'];

		$nom_tuteur = $_POST['NOM_TUTEUR'];
		$prenom_tuteur = $_POST['PRENOM_TUTEUR'];
		$service_tuteur = $_POST['SERVICE_TUTEUR'];
		$statut_tuteur = $_POST['STATUT_TUTEUR'];
		$tel_tuteur = $_POST['TEL_TUTEUR'];
		$mail_tuteur = $_POST['MAIL_TUTEUR'];

		$sql = "INSERT INTO `ENTREPRISE`(`NOM_ENTREPRISE`, `TYPE_ENTREPRISE`, `ADRESSE_ENTREPRISE`, `CPOSTAL_ENTREPRISE`, `VILLE_ENTREPRISE`, `TEL_ENTREPRISE`, `EMAIL_ENTREPRISE`)
			 	VALUES ( '$nom', '$type', '$adresse', $cpost, '$ville', $tel, '$mail');";
		$sql = addslashes($sql);

		try {
			$res = $connexion->query($sql);  
			$message = '<li>'."Entreprise \"".$nom."\" à bien été ajoutée.".'</li>'
					 . '<li>'.'<a href="'.$_SERVER['PHP_SELF'].'">'."Cliquez ici pour faire un nouvel ajout.".'</a>'.'</li>';
		} catch(PDOException $e){
			$message = '<li>'."Problème pour ajouter l'entreprises, vérifier vos données.".'</li>';
			$message .= $e->getMessage();
		}
	}
	
} else {

	// Entreprise
	// -----------

	$nom = "";
	$type = "";
	$adresse = "";
	$cpost = "";
	$ville = "";
	$tel = "";
	$mail = "";

	// Tuteur
	// -----------

	$nom_tuteur = "";
	$prenom_tuteur = "";
	$service_tuteur = "";
	$statut_tuteur = "";
	$tel_tuteur = "";
	$mail_tuteur = "";

}

// ================================
// 	DOCUMENT HTML
// ================================

?>
<!DOCTYPE html>
<html>
<head>
	<?php
	// <!--
	// ================================
	// 	paramètres du <head>
	// 	commun aux pages (inclusion de fichiers CSS, JS; balise meta; ...) 
	// ================================
	// -->
	include("../struct/param_head.php");
	echo '<title>'."Ajout d'une entreprises".$title.'</title>';
	// nom de votre page
	?>
	<link rel="stylesheet" type="text/css" href="../css/stage.css">
</head>
<body><!--	entête (header)
--><?php include("../struct/entete".$mod.".php"); ?><!--	menu horizontal
--><?php include("../struct/menu_horizontal.php"); ?><!--	menu vertical
--><?php include("../struct/menu_vertical".$mod.".php"); ?><!--
	contenu de la page
	appliquez un ID sur votre section pour y appliquer un style particulier en CSS
--><section id="ajouter" class="document">
	<form action="ajouter_entreprise.php" method="post"><!--
	 --><div class="header">
			<h2>Formulaire d'ajout d'une entreprise</h2>
		</div><!--
	 --><div>
			<label for="nom">Raison sociale</label>
			<input name="NOM" value="<?php echo $nom; ?>" type="text" id="nom">
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="type">Type</label>
			<input name="TYPE" value="<?php echo $type; ?>" type="text" id="type">
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="adresse">Adresse</label>
			<input name="ADRESSE" value="<?php echo $adresse; ?>" type="text" id="adresse">
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="cpost">Code postal</label>
			<input name="CPOST" value="<?php echo $cpost; ?>" type="number" id="cpost">
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="adresse">Ville</label>
			<input name="VILLE" value="<?php echo $ville; ?>" type="text" id="adresse">
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="tel">Téléphone</label>
			<input name="TEL" value="<?php echo $tel; ?>" type="tel" id="tel">
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="mail">Mail</label>
			<input name="MAIL" value="<?php echo $mail; ?>" type="email" id="mail">
			<span class="hint"></span>
		</div><!--
	 --><div class="header">
	 		<h3>Tuteur</h3>
	 	</div><!--
	 --><div>
			<label for="nom_tuteur">Nom</label>
			<input name="NOM_TUTEUR" value="<?php echo $nom_tuteur; ?>" type="text" id="nom_tuteur">
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="prenom_tuteur">Prénom</label>
			<input name="PRENOM_TUTEUR" value="<?php echo $prenom_tuteur; ?>" type="text" id="prenom_tuteur">
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="service_tuteur">Service</label>
			<input name="SERVICE_TUTEUR" value="<?php echo $service_tuteur; ?>" type="text" id="service_tuteur">
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="statut_tuteur">Statut</label>
			<input name="STATUT_TUTEUR" value="<?php echo $statut_tuteur; ?>" type="text" id="statut_tuteur">
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="tel_tuteur">Téléphone</label>
			<input name="TEL_TUTEUR" value="<?php echo $tel_tuteur; ?>" type="tel" id="tel_tuteur">
			<span class="hint"></span>
		</div><!--
	 --><div>
			<label for="mail_tuteur">Mail</label>
			<input name="MAIL_TUTEUR" value="<?php echo $mail_tuteur; ?>" type="email" id="mail_tuteur">
			<span class="hint"></span>
		</div><!--
	 --><div>
	 		<input class="submit transition" type="submit" value="Soumettre">
	 	</div>
	</form>
<?php include("../struct/message.php"); ?>
</section><!-- Pied de page (footer)
--><?php include("../struct/pieddepage.php"); ?>
</body>
</html>