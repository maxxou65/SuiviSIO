console.log("Script ouvert");
var liste=document.getElementById('CODE_CLASSE');
    liste.onchange=function(){
    var valeur=liste.value;
    alert(valeur);
};