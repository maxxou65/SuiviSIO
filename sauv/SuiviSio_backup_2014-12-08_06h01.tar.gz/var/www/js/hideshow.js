$(document).ready(function() {
	console.log("Script 'hideshow.js' ouvert");


	$('.menu_header').click(function(){
		cl("Entête de menu cliqué");
		$('.menu_elt').hide();
	});


	function cl(message){
		console.log(message);
	}

});