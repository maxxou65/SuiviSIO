<!--
================================
	Création de la session
	Redirection des utilisateurs non identifié
================================
-->
<?php
session_start();
if(!isset($_SESSION['CONNEXION'])){
	header('Location: ../utilisateur_inconnu.php');
	exit;
} else {
	// création de la connexion vers la base
	// n'hésitez pas à améliorer le fichier connexion.php si besoin est
	// mais faites une copie avec un nom différent
	if (!(isset($connexion))) {
		include_once("../connexion/connexion_by_id.php");
		$identifiant = strtolower($_SESSION['CONNEXION']['ID_CONNEXION']);
		$mdp = strtolower($_SESSION['CONNEXION']['MDP_CONNEXION']);
		$connexion = getConnexion($identifiant, $mdp);
	}
}
?>
<!--
================================
	
================================
-->
<?php
	// ici, vos scripts ...
	// of course
?>
<!DOCTYPE html>
<html>
<head>
	<!--
		paramètres du <head>
		commun aux pages (inclusion de fichiers CSS, JS; balise meta; ...) 
	-->
	<?php include("./struct/param_head.php");
	echo '<title>'."".$title.'</title';
	// nom de votre page
	?>

</head>
<body><!--
	entête (header)
--><?php include("./struct/entete.php"); ?><!--
	menu horizontal
--><?php include("./struct/menu_horizontal.php"); ?><!--
	menu vertical
--><?php include("./struct/menu_vertical.php"); ?><!--
	contenu de la page
	appliquez un ID sur votre section pour y appliquer un style particulier en CSS
--><section id="" class="document">
	<p>- Dis camion ...?</p>
	<p>- ... Camion ?</p>
	<p>- Pouet pouet !</p>
	<h1>Vous êtes perdu ?</h1>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
	tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
	quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
	consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
	cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
	proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
</section><!--
	Pied de page (footer)
--><?php include("./struct/pieddepage.php"); ?>
</body>
</html>