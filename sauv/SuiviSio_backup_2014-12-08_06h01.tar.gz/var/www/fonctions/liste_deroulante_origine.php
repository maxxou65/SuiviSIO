<?php
	/*
		Cette fonction liste les promotions.
		En paramètre d'entrée, il y a la variable connexion pour intéragir avec la base de données
		et le code_date afin de vérifier la condition de test pour la selection
		Cette fonction retourne le code généré pour avoir une liste déroulante de dates
	*/
	function lister_origine($connexion,$code_origine)
	{
		// on remplit la liste des fonctions
		$requete="SELECT ID_ORIGINE, BAC_ORIGINE FROM ORIGINE;";
		$tableau=array();
		try{
			$resultats=$connexion->query($requete);
			$tableau=$resultats->fetchAll(PDO::FETCH_ASSOC);
		}
		catch(PDOException $e)
		{
			$message="problème pour accéder aux informations sur les diplomes acquis.<br/>";
			$message=$message.$e->getMessage();
		}
		$liste_origine="\n<input list='origine'><datalist id='origine'>\n";
		foreach($tableau as $ligne)
		{
			$liste_origine=$liste_origine."<option value='".$ligne['BAC_ORIGINE']."'>";
		}
		$liste_origine=$liste_origine."</datalist>";
		return $liste_origine;
	}
?>