<?php
?>
<!DOCTYPE html>
<html>
<head>
	<!--
		paramètres du <head>
		commun aux pages (inclusion de fichiers CSS, JS; balise meta; ...) 
	-->
	<?php include("./struct/param_head.php");
	echo '<title>'."Erreur d'authentification".$title.'</title>';
	// nom de votre page
	?>
</head>
<body><!--
	entête (header)
--><?php include("./struct/entete.php"); ?><!--
	contenu de la page
	appliquez un ID sur votre section pour y appliquer un style particulier en CSS
--><section id="" class="document">
	<div class="placer">
		<p>Vous n'êtes pas authentifié</p>
		<p>(brigand !)</p>
		<p><a href="./index.php">Page de connexion</a></p>
	</div>
</section><!--
	Pied de page (footer)
--><?php include("./struct/pieddepage.php"); ?>
</body>
</html>