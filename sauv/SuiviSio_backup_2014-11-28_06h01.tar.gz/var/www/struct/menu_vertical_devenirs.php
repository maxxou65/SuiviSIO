<nav class="menu_vertical">
	<ul>
		<!-- Retour vers l'accueil -->
		<li id="home" class="menu_header"><a href="../mod_devenirs/index_devenirs.php"><img src="../img/home_16-16.png">Accueil</a></li>
		<!-- Diplomés -->
		<li class="separateur"></li>
		<li class="menu_header">Diplomés</li>
		<li class="separateur"></li>
		<li class="menu_elt"><a href="#"><img src="../img/arrleft_16-16.png">Gérer</a></li>
		<li class="menu_elt"><a href="#"><img src="../img/arrleft_16-16.png">ajouter</a></li>
		<li class="menu_elt"><a href="#"><img src="../img/arrleft_16-16.png">Modifier</a></li>
		<li class="menu_elt"><a href="#"><img src="../img/arrleft_16-16.png">Consulter</a></li>
	</ul>
</nav>