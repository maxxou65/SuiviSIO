<meta charset="UTF-8">
<link rel="stylesheet" type="text/css" href="../css/style.css">
<link rel="icon" type="image/png" href="../img/favicon.ico">
<link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
<script src="../js/jquery-2.1.1.min.js" type="text/javascript"></script>

<?php $title = " - Suivio des SIO"; ?>
<!--<script type='text/javascript' src='../js/suggerer_mots.js'></script>-->
