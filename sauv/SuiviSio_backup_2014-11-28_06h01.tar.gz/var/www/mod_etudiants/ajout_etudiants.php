<!--
================================
	Création de la session
	Redirection des utilisateurs non identifié
================================
-->
<?php
	include_once("../struct/session.php");
	$_SESSION['MOD'] = "_"."etudiants"; // définition du module
	$mod = $_SESSION['MOD'];
?>
<!--
================================
	
================================
-->
<?php

include_once("../fonctions/liste_deroulante_classe.php");
include_once("../fonctions/liste_deroulante_promotion.php");
include_once("../fonctions/liste_deroulante_origine.php");
include_once("../fonctions/liste_deroulante_regime.php");
include_once("../fonctions/liste_deroulante_specialite.php");

$code_classe=0;
$code_promotion=0;
$code_origine=0;
$code_regime=0;
$code_spe=0;

if (isset($_POST["NOM_ETU"])) 
{
	$origine=$_POST["ID_ORIGINE"];
	$promotion=$_POST["ID_PROMOTION"];
	$specialite=$_POST["CODE_SPECIALITE"];
	$classe=$_POST["CODE_CLASSE"];
	$nom=$_POST["NOM_ETU"];
	$prenom=$_POST["PRENOM_ETU"];
	$dnaissance=$_POST["DNAISSANCE_ETU"];
	$regime=$_POST["REGIME"];

	//Formulaire soumis -> recuperation des données
	$requete2="SELECT MAX(ID_ETU) as idetu_max FROM ETUDIANT_TEMP;";
	$resultat=$connexion->query($requete2);
	$tab=$resultat->fetchAll(PDO::FETCH_ASSOC);
	$idetu=$tab[0]['idetu_max'];
	$idetu=$idetu+1;

	$requete="INSERT INTO ETUDIANT_TEMP (ID_ORIGINE, ID_PROMOTION, CODE_SPECIALITE, CODE_CLASSE, NOM_ETU, PRENOM_ETU, DNAISSANCE_ETU, DOUBLANT1_ETU, DOUBLANT2_ETU, DIPLOME_ETU, REGIME) VALUES 
	($origine, $promotion,'$specialite', '$classe', '$nom', '$prenom', '$dnaissance', 0, 0, 0, '$regime')";
	try 
	{
		$connexion->exec($requete);
	}
	catch (PDOException $e) 
	{
		$message="Problème pour insérer les informations de l'étudiant.";
		$message=$message.$e->getMessage();
	}

}
else {
// INITIALISATION DES DONNEES
	$idetu="";
	$origine="";
	$promotion="";
	$specialite="";
	$classe="";
	$nom="";
	$prenom="";
	$dnaissance="";
	$regime="";
}


?>
<!DOCTYPE html>
<html>
<head>
	<!--
	================================
		paramètres du <head>
		commun aux pages (inclusion de fichiers CSS, JS; balise meta; ...) 
	================================
	-->
<?php include("../struct/param_head.php");
echo '<title>'."Module étudiants".$title.'</title>';
	// nom de votre page
?>
<link rel="stylesheet" type="text/css" href="../css/etudiants.css">
</head>
<body><!--
	entête (header)
--><?php include("../struct/entete".$mod.".php"); ?><!--
	menu horizontal
--><?php include("../struct/menu_horizontal.php"); ?><!--
	menu vertical
--><?php include("../struct/menu_vertical".$mod.".php"); ?><!--

--><section id="aj_etu" class="document">
		<h1>Ajout d'un étudiant</h1>
		<div class="placer">
			<form action="ajout_etudiants.php" method="post"><!--
		-->		<div>
					<label for="nom_etu">Nom</label>
					<input id="nom_etu" type="text" name="NOM_ETU" value="<?php echo $nom ;?>">
				</div>
				<div>
					<label for="prenom_etu">Prénom</label>
					<input id="prenom_etu" type="text" name="PRENOM_ETU" value="<?php echo $prenom ;?>">
				</div>
				<div>
					<label for="dnaissance_etu">Date de naissance</label>
					<input id="dnaissance_etu" type="date" name="DNAISSANCE_ETU" value="<?php echo $dnaissance ;?>">
				</div>
		 		<div>
					<label>Classe</label><?php echo lister_classe($connexion,"SIO1"); ?><br/>
				</div>
				<div>
					<label>Promotion</label><?php echo lister_promotion($connexion,$code_promotion); ?><br/>
				</div>
				<div>
					<label>Origine</label><?php echo lister_origine($connexion,$code_origine); ?><br/>
				</div>
				<div>
					<label>Régime</label><?php echo lister_regime($connexion,$code_regime); ?><br/>
				</div>
				<div>
					<label>Spécialité envisagée</label><?php echo lister_specialite($connexion,$code_spe); ?><br/>
				</div>
				<input class="submit" type="submit" value="Valider">
				<span><?php if(isset($message)) echo $message; ?></span>
			</form>	
		</div>
	</section><!--<!
	Pied de page (footer)
--><?php include("../struct/pieddepage.php"); ?>
</body>
</html>