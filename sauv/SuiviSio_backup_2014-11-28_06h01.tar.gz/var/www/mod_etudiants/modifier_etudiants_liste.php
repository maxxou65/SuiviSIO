<!--
================================
	Création de la session
	Redirection des utilisateurs non identifié
================================
-->
<?php
session_start();
if(!isset($_SESSION['CONNEXION'])){
	header('Location: ../utilisateur_inconnu.php');
	exit;
} else {
	// création de la connexion vers la base
	// n'hésitez pas à améliorer le fichier connexion.php si besoin est
	// mais faites une copie avec un nom différent
	if (!(isset($connexion))) {
		include_once("../connexion/connexion_by_id.php");
		$identifiant = strtolower($_SESSION['CONNEXION']['ID_CONNEXION']);
		$mdp = strtolower($_SESSION['CONNEXION']['MDP_CONNEXION']);
		$connexion = getConnexion($identifiant, $mdp);
	}
	$_SESSION['MOD'] = "_"."etudiants"; // définition du module
	$mod = $_SESSION['MOD'];
}
?>
<!--
================================
	
================================
-->
<?php
// Requete pour selectionner les etudiants

$select_stage = "SELECT ID_ETU, NOM_ETU, PRENOM_ETU, DNAISSANCE_ETU, BAC_ORIGINE, CLASSE.CODE_CLASSE, CODE_SPECIALITE, REGIME, ANNEE, DOUBLANT1_ETU, DOUBLANT2_ETU, DIPLOME_ETU FROM ETUDIANT INNER JOIN ORIGINE on ETUDIANT.ID_ORIGINE=ORIGINE.ID_ORIGINE inner join PROMOTION on ETUDIANT.ID_PROMOTION=PROMOTION.ID_PROMOTION inner join CLASSE on ETUDIANT.CODE_CLASSE=CLASSE.CODE_CLASSE ORDER BY ID_ETU ASC;";
try {  
	$res = $connexion->query($select_stage);  
}
catch(PDOException $e){
	$message = "Problème pour d'accès".'<br>'.$e->getMessage();
}

// table pour <table>
// remplissage du resultat de la requete dans $table_etudiant
$table_etudiant = $res->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html>
<head>
	<!--
		paramètres du <head>
		commun aux pages (inclusion de fichiers CSS, JS; balise meta; ...) 
	-->
	<?php include("../struct/param_head.php");
	echo '<title>'."Module étudiants".$title.'</title>';
	// nom de votre page
	?>
	<link rel="stylesheet" type="text/css" href="../css/etudiants.css">
</head>
<body><!--
	entête (header)
--><?php include("../struct/entete".$mod.".php"); ?><!--
	menu horizontal
--><?php include("../struct/menu_horizontal.php"); ?><!--
	menu vertical
--><?php include("../struct/menu_vertical".$mod.".php"); ?><!--
	contenu de la page
	appliquez un ID sur votre section pour y appliquer un style particulier en CSS
--><section id="gerer_stage" class="document">
	<table>
		<thead>
			<tr>
				<th colspan="12">Etudiants</th>
				<!--<th colspan="2">Entreprise</th>
				<th colspan="4">Tuteur de stage</th>
				<th colspan="2">Professeur</th>-->
			</tr>
			<tr>
				<th>ID</th>
				<th>Nom</th>
				<th>Prenom</th>
				<th>Date de naissance</th>
				<th>Bac</th> 
				<th>Classe</th>
				<th>Spécialité</th>
				<th>Regime</th> 
				<th>Promotion</th>
				<th>Redoublé 1</th> 
				<th>Redoublé 2</th>
				<th>Diplomé</th> 
			</tr>
		</thead>
		<tbody>
			<?php
			// table_row pour <tr> et table_data pour <td>
            $i=0;
			foreach ($table_etudiant as $table_row) {
                $ID_ETU=$table_row['ID_ETU'];
                $NOM_ETU=$table_row['NOM_ETU'];
                $PRENOM_ETU=$table_row['PRENOM_ETU'];
                $DNAISSANCE_ETU=$table_row['DNAISSANCE_ETU'];
                $BAC_ORIGINE=$table_row['BAC_ORIGINE'];
                $CODE_CLASSE=$table_row['CODE_CLASSE'];
                $CODE_SPECIALITE=$table_row['CODE_SPECIALITE'];
                $REGIME=$table_row['REGIME'];
                $DOUBLANT1_ETU=$table_row['DOUBLANT1_ETU'];
                $DOUBLANT2_ETU=$table_row['DOUBLANT2_ETU'];
                $DIPLOME_ETU=$table_row['DIPLOME_ETU'];                    
				echo '<tr>';
                echo "<td><input type='text' name=\"tab[$i][ID_ETU]\" readonly value='$ID_ETU'/></td>\n";
                    echo "<td><input type='text' onblur='valid(this);' name=\"tab[$i][NOM_ETU]\" value='$NOM_ETU'/></td>\n";
                    echo "<td><input type='text' onblur='valid(this);' name=\"tab[$i][PRENOM_ETU]\" value='$PRENOM_ETU'/></td>\n";
                    echo "<td><input type='date' onblur='valid(this);' name=\"tab[$i][DNAISSANCE_ETU]\" value='$DNAISSANCE_ETU'/></td>\n";
                    echo "<td><input type='text' onblur='valid(this);' name=\"tab[$i][BAC_ORIGINE]\" value='$BAC_ORIGINE'/></td>\n";
                    echo "<td><input type='text' onblur='valid(this);' name=\"tab[$i][CODE_CLASSE]\" value='$CODE_CLASSE'/></td>\n";
                    echo "<td><input type='text' onblur='valid(this);' name=\"tab[$i][CODE_SPECIALITE]\" value='$CODE_SPECIALITE'/></td>\n";
                    echo "<td><input type='text' onblur='valid(this);' name=\"tab[$i][REGIME]\" value='$REGIME'/></td>\n";
                    echo "<td><input type='text' onblur='valid(this);' name=\"tab[$i][DOUBLANT1_ETU]\" value='$DOUBLANT1_ETU'/></td>\n";
                    echo "<td><input type='text' onblur='valid(this);' name=\"tab[$i][DOUBLANT2_ETU]\" value='$DOUBLANT2_ETU'/></td>\n";
                    echo "<td><input type='text' onblur='valid(this);' name=\"tab[$i][DIPLOME_ETU]\" value='$DIPLOME_ETU'/></td>\n";
                
				foreach ($table_row as $table_data) {
                    
                    
				}
				echo '</tr>';
                $i++;
			}
			?>
		</tbody>
	</table>
</section><!--	Pied de page (footer)
--><?php include("../struct/pieddepage.php"); ?>
</body>
</html>