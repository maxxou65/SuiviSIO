<!--
================================
	Création de la session
	Redirection des utilisateurs non identifié
================================
-->
<?php
session_start();
if(!isset($_SESSION['CONNEXION'])){
	header('Location: ../utilisateur_inconnu.php');
	exit;
} else {
	// création de la connexion vers la base
	// n'hésitez pas à améliorer le fichier connexion.php si besoin est
	// mais faites une copie avec un nom différent
	if (!(isset($connexion))) {
		include_once("../connexion/connexion_by_id.php");
		$identifiant = strtolower($_SESSION['CONNEXION']['ID_CONNEXION']);
		$mdp = strtolower($_SESSION['CONNEXION']['MDP_CONNEXION']);
		$connexion = getConnexion($identifiant, $mdp);
	}
	$_SESSION['MOD'] = "_"."stages"; // définition du module
	$mod = $_SESSION['MOD'];
}
?>
<!--
================================
	Inclusion des fichiers permettant l'affichage des listes déroulantes
	Initialisation des variables
================================
-->
<?php
// création de la connexion vers la base
// n'hésitez pas à améliorer le fichier connexion.php si besoin est
// mais faites une copie avec un nom différent

// Inclusion de tous les fichiers comportant une ou des fonctions de listes déroulantes
$tables=array("prof","date","classe","etudiant","tuteur");
for($i=0;$i<4;$i++)
{
	include_once("../fonctions/liste_deroulante_".$tables[$i].".php");
}

/* Ici vos scripts ...
   ... of course */
   
/* VARIABLES */
$id_tuteur=0;
$id_prof=0;
$code_date=0;
$code_classe=0;
$id_etu=0;
?>
<!DOCTYPE html>
<html>
<head>
	<!--
	================================
		paramètres du <head>
		commun aux pages (inclusion de fichiers CSS, JS; balise meta; ...) 
	================================
	-->
	<?php include("../struct/param_head.php");
	echo '<title>'."Module de gestion des stages et des entreprises".$title.'</title>';
	// nom de votre page
	?>
	<link rel="stylesheet" type="text/css" href="../css/stage.css">
</head>
<body>
	<!-- entête (header) -->
	<?php include("../struct/entete".$mod.".php"); ?>
	<!-- menu horizontal -->
	<?php include("../struct/menu_horizontal.php"); ?>
	<!-- menu vertical -->
	<?php include("../struct/menu_vertical".$mod.".php"); ?><!--
	contenu de la page
	appliquez un ID sur votre section pour y appliquer un style particulier en CSS
--><section id="ajouter_stage" class="document">
																		<!-- Endroit où il faut modifier -->
	<h1 id="titre">
		Ajout d'un stage
	</h1>
	<div class="placer placer_stage" >
		<!-- 
			Formulaire d'ajout de stage aux étudiants 
		-->
		<form class="form" id="ajout_stage" >
			<!-- 
				Nom du tuteur pour le stage 
			-->
			<label>Tuteur</label><input type ="search" name="nom_tuteur" ><br/>
			<!--<label>Tuteur</label><?php //echo lister_tuteur($connexion,$id_tuteur); ?><br/>-->
			<!-- 
				Liste déroulante d'étudiant concerné par le stage 
			-->
			<label>Etudiant</label><?php echo lister_etudiant($connexion,$id_etu); ?><br/>
			<!-- 
				Entreprise qui permet le stage 
			-->
			<label>Entreprise</label><input type="text" name="id_entr" ><br/>
			<!-- 
				Période de stage 
			-->
			<label>Date de stage</label><?php echo lister_date($connexion,$code_date); ?><br/>
			<!-- 
				Liste déroulante de professeur supervisant le stage 
			-->
			<label>Superviseur</label><?php echo lister_superviseur2($connexion,$id_prof,"ajout_champ_stage"); ?><br/>
			<!-- 
				Liste déroulante de professeur visitant le stage 
			-->
			<label class="label_ajout_stage" >Visiteur</label><?php echo lister_visiteur($connexion,$id_prof); ?><br/>
			<!-- 
				Liste déroulante de la classe de l'étudiant
			-->
			<label class="label_ajout_stage" >Classe</label><?php echo lister_classe($connexion,$code_classe); ?><br/>
			<!--
				Bouton d'enregistrement des champs du formulaire
			-->
			<br/><input type="submit" value="Enregistrer" class="submit">
		</form>
	</div>
</section><!--
	Pied de page (footer)
--><?php include("../struct/pieddepage.php"); ?>
</body>
</html>