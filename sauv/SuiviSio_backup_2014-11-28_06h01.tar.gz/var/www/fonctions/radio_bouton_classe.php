﻿<?php
	function donner_radio_bouton_classe($connexion,$code_classe){
	// on remplit la liste des fonctions
		$requete="select CODE_CLASSE from CLASSE where CODE_CLASSE!='DIPLOME'";
		$tableau=array();
		try{
			$resultats=$connexion->query($requete);
			$tableau=$resultats->fetchAll(PDO::FETCH_ASSOC);
		}
		catch(PDOException $e)
		{
			$message="problème pour accéder aux informations des classes<br/>";
			$message=$message.$e->getMessage();
		}		
		$radio_boutons="";
		$i=0;
		foreach($tableau as $ligne)
		{
			$selected="";
			// On veut que la première option soit sélectionnée
			// ----------------------
			if($i==0){
				$selected="checked";
			}
			if($i<1){
				$i++;
			}
			// ----------------------
			$radio_boutons=$radio_boutons."<input type='radio' 
												  name='CODE_CLASSE' 
												  id='CODE_CLASSE'
												  value='".$ligne['CODE_CLASSE']."' $selected/>
			<label class='.classe' for=".$ligne['CODE_CLASSE']." ";
			$radio_boutons=$radio_boutons."> ".strtolower($ligne['CODE_CLASSE'])."</label>\n";
		}
		return $radio_boutons;
	}
	
?>