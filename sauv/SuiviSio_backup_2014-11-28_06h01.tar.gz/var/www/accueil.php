<?php
session_start();
if(!isset($_SESSION['CONNEXION'])){
	header('Location: ./utilisateur_inconnu.php');
	exit;
} else {
	// création de la connexion vers la base
	// n'hésitez pas à améliorer le fichier connexion.php si besoin est
	// mais faites une copie avec un nom différent
	if (!(isset($connexion))) {
		include_once("./connexion/connexion_by_id.php");
		$identifiant = strtolower($_SESSION['CONNEXION']['ID_CONNEXION']);
		$mdp = strtolower($_SESSION['CONNEXION']['MDP_CONNEXION']);
		$connexion = getConnexion($identifiant, $mdp);
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<!--
		paramètres du <head>
		commun aux pages (inclusion de fichiers CSS, JS; balise meta; ...) 
	-->
	<?php include("./struct/param_head.php"); ?>
	<link rel="stylesheet" type="text/css" href="./css/accueil.css">
	<title>Suivi des SIO</title>
</head>
<body><!--
	entête (header)
--><?php include("./struct/entete.php"); ?><!--
	contenu de la page
	appliquez un ID sur votre section pour y appliquer un style particulier en CSS
--><section id="" class="document">
	<div class="placer">
		<p>
			<?php
			echo "Bienvenu, M. ou MME l'".$identifiant." !";
			?>
		</p>
		<p>Choississez dans le menu, bon dieu !</p>
		<div id="boutons_accueil">
			<a href="./mod_etudiants/index_etudiants.php">
				<span>Module étudiants</span>	
			</a><!--
		 --><a href="./mod_stages/index_stages.php">
		 		<span>Module stages</span>
		 	</a><!--
		 --><a href="./mod_devenirs/index_devenirs.php">
		 		<span>Module devenirs</span>
		 	</a>
	 	</div>
	</div>
</section><!--
	Pied de page (footer)
--><?php include("./struct/pieddepage.php"); ?>
</body>
</html>